# Making the Plantation Tracker Report Dynamic

## Executive recommendation

The generated PNG should be treated as a **visual design reference**, not as the report itself. A dynamic version should be implemented as a responsive HTML dashboard inside the existing plantation-tracker application. The dashboard should fetch live data through the repository’s existing `/api/gas-sync` proxy, calculate the KPIs and chart series in the browser or in a dedicated server-side summary endpoint, and render the result with ordinary HTML/CSS plus the project’s existing chart and map libraries.

The repository already contains most of the required foundation. The Apps Script exposes `?list=1` for grouped `App_Entry` submissions and `?officialSummary=1` for the two official report sheets. The Vercel function at `api/gas-sync.js` forwards those GET requests to Apps Script and applies cache headers. The current application already uses `/api/gas-sync?list=1` for national map data and already has an official-report card that consumes `/api/gas-sync?officialSummary=1`.[1] [2] [3]

> **Important distinction:** the visual mockup shows “survival rate”, but the current `App_Entry` and `Growth_Log` schemas do not yet provide a complete baseline-versus-follow-up survival calculation. Until that calculation is defined, the KPI should be labelled “Average NDVI”, “Records with Growth Readings”, or “Data Quality Score”, or the backend should add a dedicated survival aggregation.

## Current data flow

| Layer | Current implementation | Role in the dynamic dashboard |
|---|---|---|
| Data capture | App writes submissions and growth readings to Google Apps Script | Source of new plantation records and monitoring observations |
| Spreadsheet storage | `App_Entry`, `Growth_Log`, `User_Profile`, official report sheets | Persistent data store |
| Backend bridge | `api/gas-sync.js` | Avoids browser-to-GAS CORS problems and hides the GAS URL |
| Apps Script reads | `doGet(e)` with `list`, `officialSummary`, `directory`, and other branches | Converts sheet rows into JSON |
| Frontend | Existing React utilities and legacy report code | Fetches data, caches it, filters it, and renders maps/cards |
| Report artifact | Static HTML/XLSX under `public/reports` | Historical/downloadable snapshot only; not a live dashboard |

The most useful existing response is `GET /api/gas-sync?list=1`. It returns one object per submission, with a `seedlings[]` array, latitude/longitude, location fields, planting date, NDVI, and officer/farmer metadata. The existing `GET /api/gas-sync?officialSummary=1` returns pre-aggregated official-report values including total entries, total trees, upazila totals, category totals, and data-quality counts.[2]

## Recommended dashboard structure

Create a new live route or page such as `/reports/live` with the following sections:

| Dashboard area | Live source | Calculation or rendering |
|---|---|---|
| Total trees | `list=1` or official summary | Sum `seedlings[].quantity`, or use official-summary total when the official report is selected |
| Total submissions | `list=1` | Count unique `submissionId` values |
| Active sites/upazilas | `list=1` | Count unique district/upazila combinations |
| Last updated | response timestamp plus `submittedAt` maximum | Display the latest successful refresh time and latest data timestamp separately |
| Monthly planting trend | `list=1` | Group tree quantity by `plantingDate` month |
| Upazila performance | `list=1` | Group tree quantity by upazila; sort descending |
| Category distribution | `list=1` | Group seedling quantity by category |
| Plantation map | `list=1` | Plot valid latitude/longitude records; reuse existing map data hook |
| Growth/health panel | `Growth_Log` endpoint needed | Group NDVI, height, and health status by entry or site |
| Official report panel | `officialSummary=1` | Render the already implemented government-report aggregation |

For filters, use district, region, upazila, date-from, date-to, source type, and category. Filtering should be reflected in the URL query string so a report view can be bookmarked or shared.

## Frontend data adapter

Add a typed adapter rather than letting individual components parse raw sheet data. A minimal TypeScript version is:

```ts
import type { NationalEntry } from '@/types/plantation';

export async function fetchReportEntries(params: {
  district?: string;
  region?: string;
} = {}): Promise<NationalEntry[]> {
  const query = new URLSearchParams({ list: '1' });
  if (params.district) query.set('district', params.district);
  if (params.region) query.set('region', params.region);

  const response = await fetch(`/api/gas-sync?${query.toString()}`, {
    headers: { Accept: 'application/json' },
  });
  if (!response.ok) throw new Error(`Report request failed: ${response.status}`);

  const payload = await response.json();
  if (!payload?.ok || !Array.isArray(payload.entries)) {
    throw new Error(payload?.error || 'Invalid report response');
  }
  return payload.entries;
}

export async function fetchOfficialSummary() {
  const response = await fetch('/api/gas-sync?officialSummary=1', {
    headers: { Accept: 'application/json' },
  });
  if (!response.ok) throw new Error(`Official summary failed: ${response.status}`);
  const payload = await response.json();
  if (!payload?.ok) throw new Error(payload?.error || 'Invalid official summary');
  return payload;
}
```

The repository already has `src/utils/useMapData.ts`, which implements national-entry loading, local caching, and stale-data fallback. Reuse that behavior or extract its request/cache logic into a shared `reportData.ts` utility rather than adding a second incompatible cache implementation.[4]

## KPI and chart transformation

Keep all aggregation in one pure function so the cards, charts, table, and export use exactly the same numbers. The following example supports the current grouped response shape:

```ts
function quantityOf(entry: NationalEntry): number {
  return (entry.seedlings ?? []).reduce((total, seedling) => {
    const value = Number(seedling.quantity ?? 0);
    return total + (Number.isFinite(value) ? value : 0);
  }, 0);
}

function monthKey(value?: string): string {
  if (!value) return 'Unknown';
  const match = String(value).match(/^(\d{4})[-/](\d{1,2})/);
  return match ? `${match[1]}-${match[2].padStart(2, '0')}` : 'Unknown';
}

export function buildReportModel(entries: NationalEntry[]) {
  const byMonth = new Map<string, number>();
  const byUpazila = new Map<string, number>();
  const byCategory = new Map<string, number>();
  const sites = new Set<string>();

  for (const entry of entries) {
    const quantity = quantityOf(entry);
    const upazila = entry.upazila || 'অজানা';
    sites.add(`${entry.district || 'অজানা'}|${upazila}`);
    byUpazila.set(upazila, (byUpazila.get(upazila) || 0) + quantity);

    const month = monthKey((entry as any).plantingDate || entry.submittedAt);
    byMonth.set(month, (byMonth.get(month) || 0) + quantity);

    for (const seedling of entry.seedlings ?? []) {
      const category = seedling.category || 'অন্যান্য';
      const count = Number(seedling.quantity ?? 0) || 0;
      byCategory.set(category, (byCategory.get(category) || 0) + count);
    }
  }

  return {
    totalEntries: entries.length,
    totalTrees: entries.reduce((sum, entry) => sum + quantityOf(entry), 0),
    activeSites: sites.size,
    byMonth: [...byMonth].sort(([a], [b]) => a.localeCompare(b)),
    byUpazila: [...byUpazila]
      .map(([label, value]) => ({ label, value }))
      .sort((a, b) => b.value - a.value),
    byCategory: [...byCategory].map(([label, value]) => ({ label, value })),
  };
}
```

Use the existing `NationalEntry` type as the base, but add optional fields such as `plantingDate`, `ndvi`, `submittedAt`, and `healthStatus` if the component needs them. Avoid reading Bengali sheet-column names directly from React components; that translation belongs in Apps Script.

## Route and component layout

A maintainable React implementation would be organized approximately as follows:

```text
src/
  pages/LiveReportPage.tsx
  components/report/
    ReportHeader.tsx
    ReportKpiCards.tsx
    PlantingTrendChart.tsx
    UpazilaPerformanceChart.tsx
    CategoryChart.tsx
    ReportMap.tsx
    ReportTable.tsx
    ReportFilters.tsx
  utils/reportData.ts
  utils/reportModel.ts
```

The page should load data once, expose `refresh()` explicitly, and show the timestamp of the last successful refresh. Each chart should receive transformed data through props. This keeps chart-library details out of the data-fetching code and makes the same model reusable for XLSX/PDF/CSV export.

The generated visual can be reproduced closely with the repository’s existing green palette. Use CSS for the title, KPI cards, table, and responsive grid; use Chart.js for the line/bar/doughnut charts; and reuse the current map implementation instead of drawing a static map image. The result will remain searchable, accessible, mobile-friendly, and printable.

## Backend improvements needed for a genuinely live report

### 1. Add a dedicated summary endpoint for performance

The current `list=1` endpoint returns every grouped submission. That is acceptable for a small sheet, but it becomes expensive as the dataset grows. Add a new Apps Script branch such as `?reportSummary=1` that aggregates `App_Entry` server-side and returns only the KPI and chart arrays. Keep `list=1` for the map and detail table.

The response should be versioned and explicit:

```json
{
  "ok": true,
  "generatedAt": "2026-08-19T12:00:00.000Z",
  "filters": { "district": "", "region": "", "from": "", "to": "" },
  "summary": {
    "totalEntries": 2275,
    "totalTrees": 15412,
    "activeSites": 9
  },
  "monthly": [{ "label": "2026-08", "trees": 15412 }],
  "upazilas": [{ "label": "ভুরুঙ্গামারী", "trees": 4488 }],
  "categories": [{ "label": "ফলদ", "trees": 3200 }],
  "quality": []
}
```

The existing `getOfficialReportSummary_()` is already a useful model for this pattern: it reads sheets by header names, supports missing sheets, normalizes numeric values, and returns chart-ready arrays.[3]

### 2. Add a read endpoint for `Growth_Log`

`AppsScript.gs` currently writes `growth_reading` records to `Growth_Log`, but the documented GET branches do not expose those readings. Add `?growth=1` with optional `submissionId`, `district`, `upazila`, and date filters. This is required before a survival-rate card can be calculated reliably.

A defensible survival metric should be defined with the project owner. For example:

```text
survival rate = surviving plants at the latest observation / originally planted plants × 100
```

That requires either a surviving-count field in `Growth_Log` or a documented mapping from `healthStatus` to a count. A single NDVI value is not, by itself, a survival-rate numerator.

### 3. Keep official and operational reports separate

The official summary uses `মূল_ডাটা` and `১ৗ_কলাম_প্রতিবেদন`, while the operational dashboard uses `App_Entry` and optionally `Growth_Log`. Present them as two modes in the UI:

| Mode | Purpose | Data source |
|---|---|---|
| Live operations | Current submissions, sites, map, categories, monitoring | `App_Entry` plus `Growth_Log` |
| Official weekly report | Government-format totals and data-quality checks | `officialSummary=1` |

This prevents an official export snapshot from being mistaken for the latest operational data.

## Refresh and caching strategy

The existing proxy already caches the national list for 60 seconds with stale-while-revalidate and the official summary for 300 seconds.[2] Keep those defaults, then add a manual refresh button that calls the endpoint with a cache-busting query parameter only when the user explicitly requests fresh data. Do not bypass caching on every component render.

A practical frontend policy is:

| State | Behavior |
|---|---|
| First visit | Show cached data immediately if available, then refresh in the background |
| Normal navigation | Reuse data fetched within the current page session |
| Manual refresh | Fetch again, update the timestamp, and replace the cache |
| Network failure | Keep the last successful data visible and show a non-blocking warning |
| Empty dataset | Show an explicit empty state, not zero-valued fake charts |

## Exporting a dynamic report

Keep the live dashboard and the downloadable report as separate render targets. The browser dashboard can offer CSV/XLSX export from the transformed report model, while the official HTML/XLSX files under `public/reports` remain dated snapshots. If you need a new weekly artifact, generate it from the same summary model on the server or through a scheduled job, writing a new date-stamped file instead of overwriting the previous report.

The static file under `public/reports` currently contains hardcoded Bengali values and table rows, so it will not update merely because the Apps Script sheet changes.[5] Convert it into a template only if you specifically need an email-compatible HTML report; for the interactive dashboard, use the React route.

## Implementation order

1. Add `LiveReportPage` and load `/api/gas-sync?list=1` using the existing caching pattern.
2. Add `buildReportModel()` and verify totals against the current official summary for the same date range.
3. Replace the static KPI values with model values.
4. Add the monthly line chart, upazila bar chart, category chart, and live table.
5. Reuse the existing national map hook and add report filters.
6. Add `?reportSummary=1` when list payloads become too large.
7. Add `?growth=1` and define the survival-rate formula before displaying that KPI.
8. Add export actions and retain dated snapshots under `public/reports`.

## Acceptance criteria

The dynamic report is ready when a new submission in `App_Entry` appears after refresh without editing HTML; all KPI totals equal the table totals for the active filters; the map and table use the same filtered dataset; official-report mode clearly identifies its source sheets; stale-cache and network-error states are visible; and no KPI is presented with a misleading label or unsupported calculation.

## References

[1]: https://github.com/moniruzjaman/plantation-tracker/tree/main/public/reports "Plantation Tracker report artifacts"

[2]: https://github.com/moniruzjaman/plantation-tracker/blob/main/api/gas-sync.js "Plantation Tracker gas-sync Vercel proxy"

[3]: https://github.com/moniruzjaman/plantation-tracker/blob/main/gas/AppsScript.gs "Plantation Tracker Google Apps Script backend"

[4]: https://github.com/moniruzjaman/plantation-tracker/blob/main/src/utils/useMapData.ts "Plantation Tracker national map data hook"

[5]: https://github.com/moniruzjaman/plantation-tracker/blob/main/public/reports/weekly-report-2026-08-11.html "Static weekly report HTML snapshot"

